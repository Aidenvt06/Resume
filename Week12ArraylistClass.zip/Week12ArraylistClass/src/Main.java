import java.util.*;
/** Week12ArraylistClass
 * This program is using the code from last week to practice using arraylists with classes.
 * @author Aiden Thompson
 * @version 1.4
 */
public class Main {
    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        System.out.println("How many movies are in your collection?");
        int numMovies = stdin.nextInt();
        ArrayList<Movie> myCollection = new ArrayList<Movie>(numMovies);
        for (int i = 0; i<numMovies; ++i) {
            System.out.println("Please enter in the movie's title. (Spaces are denoted by '_')");
            String title = stdin.next();
            System.out.println("Please enter in the movie's rating.");
            String rating = stdin.next();
            System.out.println("Please enter when the movie came out. (mm/yyyy)");
            String date = stdin.next();
            System.out.println("Please enter in the movie's runtime in minutes.");
            double length = stdin.nextDouble();
            System.out.println("Please enter how many stars the movie was awarded.");
            int stars = stdin.nextInt();
            Movie movie1 = new Movie(title, rating, date, length, stars);
            myCollection.add(movie1);
        }
        for (int count = 0; count < myCollection.size(); ++count) {
            System.out.println("Movie = " +
                    myCollection.get(count).getTitle()
                    + " Date = " + myCollection.get(count).getDate()
                    + " Rating = " + myCollection.get(count).getRating()
                    + " Runtime = " + myCollection.get(count).getLength()
                    + " reviews = " + myCollection.get(count).getStars());
        }
        hasPhrase(myCollection, numMovies);
        longestMovies(myCollection, numMovies);
    }

    /**
     * Finds however many movies contain the key phrase
     * @param myCollection
     * @param count
     */
    public static void hasPhrase(ArrayList<Movie> myCollection, int count) {
        Scanner stdin = new Scanner(System.in);
        String key;
        System.out.println("Please enter a key phrase to search for. ");
        key = stdin.next();
        boolean found;

        for (int i = 0; i < count; ++i) {
            found = false;
           found = myCollection.get(i).getTitle().contains(key);
            if (found){
                System.out.println("This movie contains '"+ key + "' : " + myCollection.get(i).getTitle());
            }

        }
    }
    /**
     * Fetches the Movie or movies with the longest run times.
     * @param myCollection
     * @param count
     */
    public static void longestMovies(ArrayList<Movie> myCollection,int count) {
        double longestRuntime = 0;
        ArrayList<String> longestMovies = new ArrayList<>();

        for (int i=0; i<count; ++i) {
            double currentRuntime =  myCollection.get(i).getLength();
            if (currentRuntime > longestRuntime) {
                longestRuntime = currentRuntime;
                longestMovies.clear();
                longestMovies.add(myCollection.get(i).getTitle());
            } else if (currentRuntime == longestRuntime) {
                longestMovies.add(myCollection.get(i).getTitle());
            }
        }

        for (int z = 0; z < longestMovies.size(); ++z) {
            System.out.println("Movie(s) with the longest runtime (" + longestRuntime + " minutes):");
            System.out.println(longestMovies.get(z));


        }
    }
}


