/**
 * The Movie class is made to practice declaring data fields, default and non-default constructors,
 * and setting and getting methods.
 */
public class Movie {

    private String title;
    private String rating;
    private String date;
    private double length;
    private int stars;
    private String isItAMovie;

    public Movie (String name, String rate, String time, double runtime, int reviews){
        title = name;
        rating = rate;
        date = time;
        length = runtime;
        stars = reviews;
    }
    public Movie (){
        isItAMovie = "Yes, it is a movie";
    }

    /**
     * For the sake of brevity, all 5 of these methods do the same thing, that is, they are get methods to
     * be used in the main file.
     * @return
     */
    public String getTitle(){
        return title;
    }
    public String getRating(){
        return rating;
    }
    public String getDate(){
        return date;
    }
    public double getLength(){
        return length;
    }
    public int getStars(){
        return stars;
    }

    /**
     * Just like the get methods, these are basic set methods to set data from the main file.
     * @param name rate, time, runtime, reviews
     */
    public void setTitle(String name) {
        this.title = name;
    }
    public void setRating(String rate) {
        this.rating = rate;
    }
    public void setDate(String time) {
        this.date = time;
    }
    public void setLength(double runtime) {
        this.length = runtime;
    }
    public void setStars(int reviews) {
        this.stars = reviews;
    }






}
