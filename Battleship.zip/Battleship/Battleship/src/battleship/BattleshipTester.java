package battleship;

import battleship.players.athompson_BattleshipPlayer;

/**
 * Created by yoda
 */
public class BattleshipTester {

    public static final int MAX = 3;  //number of complete games to play

    public static void main(String[] args) throws Exception {

        athompson_BattleshipPlayer a = new athompson_BattleshipPlayer();
        athompson_BattleshipPlayer b = new athompson_BattleshipPlayer();

        int aWins = 0;
        int bWins = 0;

        for (int numGames = 0; numGames < MAX; numGames++) {
            a.reset();
            b.reset();

            Board aBoard = a.hideShips();
            System.out.println(aBoard);

            Board bBoard = b.hideShips();
            System.out.println(bBoard);

            int step = 1;
            int move = 0;
            while (move < 100 && !aBoard.isComplete() && !bBoard.isComplete()) {  //THIS LOOP PLAYS 1 GAME
                System.out.println("Move " + move + " ================");
                bBoard.firedAtThisRound = false;
                a.go(bBoard);
                System.out.println(bBoard);

                aBoard.firedAtThisRound = false;
                b.go(aBoard);
                System.out.println(aBoard);


                //step++;
                move++;
            }//end game loop
            if (aBoard.isComplete()) {
                System.out.println("B Wins!");
                bWins++;
            }
            if (bBoard.isComplete()) {
                System.out.println("A Wins!");
                aWins++;
            }
        }//end for all games

        System.out.println("A's total wins were " + aWins);
        System.out.println("B's total wins were " + bWins);

    }//end main()
}//end BattleshipTester class
