/**
 * I, as a new member of the University of Mary Washington community, pledge not to lie, cheat, or steal
 * and to actively contribute to a community of trust. I understand that honor is a way of life at
 * Mary Washington and that my words and deeds impact the lives of others. As a Mary Washington student,
 * I therefore promise to hold myself to the highest standards of honesty and integrity in all that I do
 * and say.
 *
 * I further pledge that I will endeavor to create a spirit of honor, both by upholding the honor system
 * myself and helping others to do so.
 */
package battleship.players;
import battleship.Board;



public class athompson_BattleshipPlayer implements BattleshipPlayer {

    //include your instance variables here to maintain a record of your game state
    //remember which of your opponent's squares you've shot at
    //remember what was revealed at each square so you can strategize future moves
    private char[][] shotBoard = new char[][]{
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'}
    };
    private boolean otherBoard;
    private boolean searching = true;
    private boolean foundLeft, foundRight, foundUp, foundDown = false;
    private int x = 0;
    private int y = 0;
    private int originalX = x;
    private int originalY = y;
    private boolean turnAround = false;
    private int count;
    private char currentTarget;
    private java.util.ArrayList<String> done = new java.util.ArrayList<String>();
    private boolean alreadyDone;
    private boolean change = true;
    /**
     * hideShips - This method is called once at the beginning of each game
     * when you need to hide your ships.
     * <p>
     * You must return a valid Board object. See that class for details.
     * Note carefully: under *no* circumstances should you return the same
     * board twice in a row; i.e., two successive calls to your hideShips()
     * method must always return *different* answers!
     */
    public Board hideShips() {

        //this code prevents cheaters - leave this here to prevent cheaters from looking at your board
        // INSERT YOUR AMAZING CODE HERE

        char[][] board = new char[10][10];
        if (otherBoard){
            otherBoard = false;
        }
        else if (!otherBoard){
            otherBoard = true;
        }
        if(!otherBoard){
        board = new char[][]{
                {'B', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'P', 'P'},
                {'B', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {'B', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {'B', ' ', ' ', 'A', 'A', 'A', 'A', 'A', ' ', ' '},
                {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {' ', 'S', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {' ', 'S', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {' ', 'S', ' ', ' ', ' ', 'D', 'D', 'D', ' ', ' '}
        };
        }
        else if(otherBoard){
            board = new char[][]{
                    {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'D', ' '},
                    {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'D', ' '},
                    {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'D', ' '},
                    {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                    {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                    {'A', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                    {'A', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                    {'A', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'S'},
                    {'A', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'P', 'S'},
                    {'A', 'B', 'B', 'B', 'B', ' ', ' ', ' ', 'P', 'S'}
            };
        }
        Board board1 = null;
        try {
            board1 = new Board(board);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return board1;
    }

    /**
     * go - This method is called repeatedly throughout the game, every
     * time it's your turn.
     * <p>
     * When it's your turn, and go() is called, you must call fireAt() on
     * the Board object which is passed as a parameter. You must do this
     * exactly *once*: trying to fire more than once during your turn will
     * be detected as cheating.
     */

    public void go(Board opponentsBoard) {

    boolean shot = false;

    // Searching phase: Fire in a checkerboard pattern. This allows me to theoretically hit every ship at
        //least once
     if (searching) {
        shotBoard[y][x] = opponentsBoard.fireAt(y, x);
        shot = true;
        alreadyDone = done.contains(String.valueOf(shotBoard[y][x]));
            if (shotBoard[y][x] != ' ' && shotBoard[y][x] != '.' && !alreadyDone) {
                    searching = false;
                currentTarget = shotBoard[y][x];
            }
            else {

                x = x+2;
                if (x >= 10 && change) {
                    x = 1;
                    ++y;
                    change = false;}
                else if (x >= 10 && !change){
                    x = 0;
                    ++y;
                    change = true;
                }
                originalX = x;
                originalY = y;
        }
    }

    // Hunting phase: After hitting a ship, search for the rest of it.
    else if (!searching && !shot) {



            if(!foundRight && !foundLeft && !foundUp && !foundDown) {

                // Check Left
                if (x - 1 >= 0 && shotBoard[y][x - 1] == '.' && !shot) {
                    shotBoard[y][x - 1] = opponentsBoard.fireAt(y, x - 1);
                    shot = true;
                    --x;
                    if (shotBoard[y][x] == currentTarget) {
                        foundLeft = true;

                    } else {
                        x = originalX;
                    }
                }

                // Check Right
                if (x + 1 < Board.WIDTH && shotBoard[y][x + 1] == '.' && !shot) {
                    shotBoard[y][x + 1] = opponentsBoard.fireAt(y, x + 1);
                    ++x;
                    shot = true;
                    if (shotBoard[y][x] == currentTarget) {
                        foundRight = true;
                    } else {
                        x = originalX;
                    }
                }

                // Check Up
                if (y - 1 >= 0 && shotBoard[y - 1][x] == '.' && !shot) {
                    shotBoard[y - 1][x] = opponentsBoard.fireAt(y - 1, x);
                    shot = true;
                    --y;
                    if (shotBoard[y][x] == currentTarget) {
                        foundUp = true;

                    } else {
                        y = originalY;
                    }
                }

                // Check Down
                if (y + 1 < Board.HEIGHT && shotBoard[y + 1][x] == '.' && !shot) {
                    shotBoard[y + 1][x] = opponentsBoard.fireAt(y + 1, x);
                    shot = true;
                    ++y;
                    if (shotBoard[y][x] == currentTarget) {
                        foundDown = true;
                    } else {
                        y = originalY;
                    }
                }
            }

            else if((foundRight || foundLeft || foundUp || foundDown) && !shot) {

                    //found it to the left
                if (foundLeft && !shot) {
                    if(x - 1 >= 0 && !turnAround && count != shipLength(currentTarget)){
                        shotBoard[y][x - 1] = opponentsBoard.fireAt(y, x - 1);
                        if (shotBoard[y][x - 1] != currentTarget){
                            turnAround = true;
                        }
                        else{--x;}
                    }//turn back if I hit the middle of a ship
                    else if(turnAround && x + 1 < Board.WIDTH && count != shipLength(currentTarget)){
                        shotBoard[y][x + 1] = opponentsBoard.fireAt(y, x + 1);
                        ++x;
                    }
                    else if(count == shipLength(currentTarget)){
                        count = 0;
                        foundLeft = false;
                        done.add(String.valueOf(currentTarget));
                        currentTarget = 'L';
                    }
                }
                //found it to the Right
                else if (foundRight && !shot) {
                    if(x + 1 < Board.WIDTH && !turnAround && count != shipLength(currentTarget)){
                        shotBoard[y][x + 1] = opponentsBoard.fireAt(y, x + 1);
                        if (shotBoard[y][x + 1] != currentTarget){
                            turnAround = true;
                        }
                        else{++x;}
                    }
                    else if(turnAround && x - 1 >= 0 && count != shipLength(currentTarget)){
                        shotBoard[y][x - 1] = opponentsBoard.fireAt(y, x - 1);
                        --x;
                    }
                    else if(count == shipLength(currentTarget)){
                        count = 0;
                        foundRight = false;
                        done.add(String.valueOf(currentTarget));
                        currentTarget = 'L';
                    }
                }//found it upwards
                else if (foundUp && !shot) {
                    if(y - 1 >= 0 && !turnAround && count != shipLength(currentTarget)){
                        shotBoard[y - 1][x] = opponentsBoard.fireAt(y - 1, x);
                        if (shotBoard[y - 1][x] != currentTarget){
                            turnAround = true;
                        }
                        else {--y;}
                    }
                    else if(turnAround && y + 1 < Board.HEIGHT && count != shipLength(currentTarget)){
                        shotBoard[y + 1][x] = opponentsBoard.fireAt(y + 1, x);
                        ++y;
                    }
                    else if(count == shipLength(currentTarget)){
                        count = 0;
                        foundUp = false;
                        done.add(String.valueOf(currentTarget));
                        currentTarget = 'L';
                    }
                }//found it downwards
                else if (foundDown && !shot) {
                    if(y + 1 < Board.HEIGHT && !turnAround && count != shipLength(currentTarget)){
                        shotBoard[y + 1][x] = opponentsBoard.fireAt(y + 1, x);
                        if (shotBoard[y + 1][x] != currentTarget){
                            turnAround = true;
                        }
                        else {++y;}
                    }
                    else if(turnAround && y - 1 >= 0 && count != shipLength(currentTarget)){
                        shotBoard[y - 1][x] = opponentsBoard.fireAt(y - 1, x);
                        --y;
                    }
                    else if(count == shipLength(currentTarget)){
                        count = 0;
                        foundDown = false;
                        done.add(String.valueOf(currentTarget));
                        currentTarget = 'L';
                    }
                    //count how many parts of the ship. Once at the max, I have destroyed the ship.
                } count = 0;
                for (int i = 0; i < 10; ++i) {
                    for (int r = 0; r < 10; ++r) {
                        if (shotBoard[i][r] == currentTarget) {
                            ++count;
                        }
                    }
                }// gets back to the searching phase
                if (!foundLeft && !foundRight && !foundUp && !foundDown) {
                    turnAround = false;
                    searching = true;
                    x = originalX;
                    y = originalY;
                    x = x+2;
                    if (x >= 10 && change) {
                        x = 1;
                        ++y;
                        change = false;}
                    else if (x >= 10 && !change){
                        x = 0;
                        ++y;
                        change = true;
                    }
                    shotBoard[y][x] = opponentsBoard.fireAt(y, x);
                    if (x >= 10 && change) {
                        x = 1;
                        ++y;
                        change = false;}
                    else if (x >= 10 && !change){
                        x = 0;
                        ++y;
                        change = true;
                    }
                }
            }


    }
}

    /**
     * shipLength - a reference log of all the ship letters and their associated length with which to
     * reference inside the go() method to cut down of code size and complexity
     */

    private int shipLength(char shipType) {
        switch (shipType) {
            case 'A': return 5;
            case 'B': return 4;
            case 'S': return 3;
            case 'D': return 3;
            case 'P': return 2;
            default: return 0;
        }
    }


    /**
     * reset - This method is called when a game has ended and a new game
     * is beginning. It gives you a chance to reset any instance variables
     * you may have created, so that your BattleshipPlayer starts fresh.
     */
    public void reset() {
        // RESET YOUR OBJECT HERE
        searching = true;
        count = 0;
        foundLeft = false;
        foundRight = false;
        foundUp = false;
        foundDown = false;
        x = 0;
        y = 0;
        originalX = x;
        originalY = y;
        turnAround = false;
        currentTarget = 'L';
        done.clear();
        change = true;
        shotBoard = new char[][]{
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
                {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'}};
    }
}