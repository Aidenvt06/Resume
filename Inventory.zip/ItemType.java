/**
 * Enum ItemType is used to select between different item types such as weapons, armor, and misc. items
 */
public enum ItemType {
    ARMOR,
    WEAPON,
    MISC
}
