/**
 * creates the object "Item" which contains all the relevant information needed about a single object
 */
public class Item {
    private ItemType itemtype;
    private String name;
    private int weight;
    private int value;
    private int strength;
//Constructor; initializes the variables to basic placeholders
    public Item() {
        itemtype = null;
        name = null;
        weight = 0;
        value = 0;
        strength = 0;
    }
// this and the subsequent get methods return the given value tied to its name
    public ItemType getItemType(){
        return this.itemtype;
    }
    public String getName(){
        return this.name;
    }
    public int getWeight(){
        return this.weight;
    }
    public int getValue(){
        return this.value;
    }
    public int getStrength(){
        return this.strength;
    }
//Same deal as the getter methods, but these are setter methods
    public void setItemType(ItemType inType){
        itemtype = inType;
    }
    public void setName(String inName){
        name = inName;
    }
    public void setWeight(int inWeight){
        weight = inWeight;
    }
    public void setValue(int inValue){
        value = inValue;
    }
    public void setStrength(int inStrength){
        strength = inStrength;
    }
}
