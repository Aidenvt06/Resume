import java.util.*;
/** Inventory
 * This program is an inventory system for an adventure text game.
 * @author Aiden Thompson
 * @version 1.11
 */

public class Main {
    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        boolean done = false;
        Inventory inventory = new Inventory();
        while (!done){
            int pick;
            System.out.println("------------------------");
            System.out.println("1. Print Inventory");
            System.out.println("2. Search for an Item");
            System.out.println("3. Drop Item");
            System.out.println("4. Equip Weapon");
            System.out.println("5. Equip Armor");
            System.out.println("6. Exit");
            pick = stdin.nextInt();
            switch (pick){
                case 1:
                    inventory.print();
                    break;
                case 2:
                    inventory.addItem(ItemGenerator.generate());
                    break;
                case 3:
                    inventory.drop();
                    break;
                case 4:
                    inventory.equipWeapon();
                    break;
                case 5:
                    inventory.equipArmor();
                    break;
                case 6:
                    done = true;
                    break;
                default:
                    System.out.println("That was an invalid option, please try again.");
                    break;
            }
            System.out.println("------------------------");
        }
    }
}