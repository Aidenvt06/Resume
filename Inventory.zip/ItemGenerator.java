/**
 * This class is dedicated to randomly generate a random item of random quality
 */

import java.util.Random;
public class ItemGenerator {
    // generates first the Item type randomly, and then randomly picks an applicable item from a list of
    // options with set names and values
    public static Item generate () {
        Random rand = new Random ();
        Item newItem = new Item();

        int randType = rand.nextInt(3);

        if (randType == 0){
            newItem.setItemType(ItemType.WEAPON);
        }
        else if (randType == 1){
            newItem.setItemType(ItemType.ARMOR);
        }
        else if (randType == 2){
            newItem.setItemType(ItemType.MISC);
        }

        int randIndex = rand.nextInt(5);

        if (newItem.getItemType() == ItemType.WEAPON){
            switch (randIndex){
                case 0:
                    newItem.setName("Steel Broadsword");
                    newItem.setWeight(20);
                    newItem.setValue(5);
                    newItem.setStrength(4);
                    break;
                case 1:
                    newItem.setName("Sturdy Stick");
                    newItem.setWeight(2);
                    newItem.setValue(1);
                    newItem.setStrength(1);
                    break;
                case 2:
                    newItem.setName("Guardsman's Bardiche");
                    newItem.setWeight(35);
                    newItem.setValue(10);
                    newItem.setStrength(6);
                    break;
                case 3:
                    newItem.setName("40000 Warhammers");
                    newItem.setWeight(60);
                    newItem.setValue(120);
                    newItem.setStrength(8);
                    break;
                case 4:
                    newItem.setName("Gandalf's Walking Stick");
                    newItem.setWeight(10);
                    newItem.setValue(500);
                    newItem.setStrength(10);
                    break;
            }
        }
        else if (newItem.getItemType() == ItemType.ARMOR){
            switch (randIndex) {
                case 0:
                    newItem.setName("Iron Cuirass");
                    newItem.setWeight(50);
                    newItem.setValue(40);
                    newItem.setStrength(5);
                    break;
                case 1:
                    newItem.setName("Shiny Thimble");
                    newItem.setWeight(1);
                    newItem.setValue(1);
                    newItem.setStrength(1);
                    break;
                case 2:
                    newItem.setName("Gambesson Jacket");
                    newItem.setWeight(10);
                    newItem.setValue(15);
                    newItem.setStrength(4);
                    break;
                case 3:
                    newItem.setName("Ceramite Pauldrons");
                    newItem.setWeight(100);
                    newItem.setValue(200);
                    newItem.setStrength(10);
                    break;
                case 4:
                    newItem.setName("Mythril Chainmail");
                    newItem.setWeight(5);
                    newItem.setValue(400);
                    newItem.setStrength(8);
                    break;
            }
        }
        else if (newItem.getItemType() == ItemType.MISC){
            switch (randIndex) {
                case 0:
                    newItem.setName("Torch");
                    newItem.setWeight(5);
                    newItem.setValue(5);
                    newItem.setStrength(0);
                    break;
                case 1:
                    newItem.setName("Bent Nail");
                    newItem.setWeight(1);
                    newItem.setValue(1);
                    newItem.setStrength(0);
                    break;
                case 2:
                    newItem.setName("Dungeon Key");
                    newItem.setWeight(1);
                    newItem.setValue(50);
                    newItem.setStrength(0);
                    break;
                case 3:
                    newItem.setName("Saint Relequary");
                    newItem.setWeight(5);
                    newItem.setValue(100);
                    newItem.setStrength(0);
                    break;
                case 4:
                    newItem.setName("Carved Wooden Pipe");
                    newItem.setWeight(2);
                    newItem.setValue(75);
                    newItem.setStrength(0);
                    break;
            }
        }
        return newItem;
    }
}
