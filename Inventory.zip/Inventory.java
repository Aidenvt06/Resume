/**
 * Creates the object "inventory" which stores items and methods to manipulate items in the inventory
 */

import java.util.*;

public class Inventory {
    private ArrayList<Item> itemList = new ArrayList<Item>();
    private int maxWeight;
    private Item equippedWeapon;
    private Item equippedArmor;

    //Constructor; initializes the variables
    public Inventory (){
        maxWeight = 300;
        equippedArmor = null;
        equippedWeapon = null;
    }
//Used to check if the item being added to the inventory is of a valid weight
    public boolean totalWeight (int weightIn){
        int total = 0;
        for (int i = 0; i < itemList.size(); ++i){
            total += itemList.get(i).getWeight();
        }
        if ((weightIn + total) <= maxWeight){
            return true;
        }
        else {return false;}
    }
//adds the newly generated item to the inventory
    public boolean addItem (Item newItem){
        if (totalWeight(newItem.getWeight())){
            itemList.add(newItem);
            return true;
        }
        else {
            System.out.println("You're carrying too much stuff! You'll need to drop something to make room.");
            return false;
        }
    }
//Prints out the inventory in a formatted list, and denotes which items are equipped
    public void print (){
        System.out.printf("%-15s %-25s %-10s %-10s %-10s%n", "Item Type", "Name", "Weight", "Value", "Strength");
        boolean equippedArmorLabelPrinted = false;
        boolean equippedWeaponLabelPrinted = false;

        for (int i = 0; i < itemList.size(); ++i) {
            Item item = itemList.get(i);
            String equippedLabel = "";

            if (!equippedArmorLabelPrinted && item.getItemType() == ItemType.ARMOR && item == equippedArmor) {
                equippedLabel = "(Equipped)";
                equippedArmorLabelPrinted = true;
            } else if (!equippedWeaponLabelPrinted && item.getItemType() == ItemType.WEAPON && item == equippedWeapon) {
                equippedLabel = "(Equipped)";
                equippedWeaponLabelPrinted = true;
            }

            if (item.getItemType() != ItemType.MISC) {
                System.out.printf("%-15s %-25s %-10d %-10d %-10d %-5s %n",
                        item.getItemType(),
                        item.getName(),
                        item.getWeight(),
                        item.getValue(),
                        item.getStrength(),
                        equippedLabel);
            } else {
                System.out.printf("%-15s %-25s %-10d %-10d %-10s%n",
                        item.getItemType(),
                        item.getName(),
                        item.getWeight(),
                        item.getValue(),
                        "N/A");
            }
        }
    }
//Drops an item to make room for others
    public void drop (){
        Scanner stdin = new Scanner(System.in);
        System.out.println("Please enter the name of the item you want dropped");
        print();
        String index = stdin.nextLine();
        for (int i = 0; i < itemList.size(); ++i) {
            if (index.equals(itemList.get(i).getName())){
                itemList.remove(i);
                break;
            }
        }
    }
//Equips a weapon in the inventory
    public void equipWeapon (){
        Scanner stdin = new Scanner(System.in);
        System.out.println("Please enter the name of the weapon you want equipped");
        String choice = stdin.nextLine();
        for (int i = 0; i < itemList.size(); ++i) {
            if ((choice.equals(itemList.get(i).getName())) && itemList.get(i).getItemType() != ItemType.WEAPON){
                System.out.println("That is not a weapon, you cannot equip it");
                break;
            }
            if (choice.equals(itemList.get(i).getName())){
                equippedWeapon = itemList.get(i);
                System.out.println("Equipped: " + equippedWeapon.getName());
                break;
            }
        }
    }
//Same concept as equipWeapon, but this time for armor
    public void equipArmor (){
        Scanner stdin = new Scanner(System.in);
        System.out.println("Please enter the name of the armor you want equipped");
        String choice = stdin.nextLine();
        for (int i = 0; i < itemList.size(); ++i) {
            if ((choice.equals(itemList.get(i).getName())) && itemList.get(i).getItemType() != ItemType.ARMOR){
                System.out.println("That is not armor, you cannot equip it");
                break;
            }
            if (choice.equals(itemList.get(i).getName())){
                equippedArmor = itemList.get(i);
                System.out.println("Equipped: " + equippedArmor.getName());
                break;
            }
        }
    }
}
